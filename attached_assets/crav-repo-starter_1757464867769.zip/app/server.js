// Minimal HTTP server (placeholder). Replace with Next.js/Vite/Express as needed.
const http = require('http');
const port = process.env.PORT || 3000;
const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('CRAudioVizAI starter is running. Replace with your app.\n');
});
server.listen(port, () => console.log(`Server listening on ${port}`));
