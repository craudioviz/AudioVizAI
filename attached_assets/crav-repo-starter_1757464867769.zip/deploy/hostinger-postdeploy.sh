#!/usr/bin/env bash
# Optional hook for cache warm-ups, DB migrations, etc.
set -euo pipefail
echo "Post-deploy hook — extend as needed."
