#!/usr/bin/env bash
set -euo pipefail

APP_PATH="${1:?APP_PATH missing}"
SERVICE="${2:-javari}"

# Use SSH config host alias if provided
RSYNC_RSH=${RSYNC_RSH:-"ssh"}

# Sync repository contents to server path
rsync -az --delete   --exclude=".git"   --exclude=".github"   --exclude="node_modules"   ./ "${APP_PATH}/"

# Install dependencies and build (Node example)
ssh $SSH_USER@$SSH_HOST 'bash -lc "
  set -e
  cd '"${APP_PATH}"'
  if [ -f package.json ]; then
    if command -v npm >/dev/null 2>&1; then
      npm ci || npm install
      if npm run | grep -q \"build\"; then npm run build; fi
    fi
  fi
"'

# Refresh env and restart
ssh $SSH_USER@$SSH_HOST "sudo /usr/local/bin/crav_env_sync.sh && sudo systemctl restart ${SERVICE} && sudo systemctl status ${SERVICE} --no-pager -l || true"
