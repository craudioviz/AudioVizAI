# CRAudioVizAI — Replit + GitHub + Hostinger Starter Repo

**Owner:** Roy Henderson (@royhenderson) — CRAudioVizAI  
**Date:** 2025-09-09

This repo is a production-ready skeleton to build/manage your site in **Replit**, store code in **GitHub**, and deploy via **GitHub Actions** to **Hostinger** (Dev → Prod). It enforces your discipline:
- Build on PC/Replit → Push to **dev** → Test → PR to **main** → Deploy
- Backups before prod deploys
- **No secrets in chat.** Live secrets stored only on servers:
  - Linux: `/home/web/.secrets/crav.ini` → rendered to `/home/web/.secrets/javari.env` (systemd `EnvironmentFile`)
  - Windows (if applicable): `C:\CRAV\secrets\crav.ini`

Domains & hosting:
- **Prod:** `craudiovizai.com` on Hostinger Cloud Professional
- **Dev:** `craudiovizaidev.com` on Hostinger Cloud Professional
- **Javari (core):** `javariai.com` on Hostinger Cloud Professional
- **Squarespace:** *Registrar/DNS only* for ~90 days; after that, transfer registrar to Hostinger.

---

## 1) Local/Replit quick start

1. Create a Repl by **Importing from GitHub** (this repo).
2. Replit will detect Node (example). You can change `run` in `.replit`.
3. Work on a `feat/*` branch → commit & push → PR to `dev` → merge (auto-deploys to Dev).
4. Test on `craudiovizaidev.com` → PR to `main` → merge (auto-deploys to Prod).

> Replit Deployments are optional for previews; **production lives on Hostinger**.

---

## 2) Repo layout

```
/
  app/                         # your app (Next.js/Vite/etc.)
  public/                      # static assets
  .replit                      # Replit run config
  replit.nix                   # Replit environment (if prompted)
  deploy/
    hostinger-deploy.sh
    hostinger-postdeploy.sh
    systemd/
      javari.service
  .github/
    workflows/
      deploy-dev.yml
      deploy-prod.yml
  README.md
```

---

## 3) Prepare Hostinger servers (one-time per box)

SSH into each server (Dev & Prod) and run:

```bash
sudo useradd -m -s /bin/bash web || true
sudo mkdir -p /var/www/app /home/web/.secrets /home/web/.ssh
sudo chown -R web:web /var/www/app /home/web/.secrets /home/web/.ssh
sudo chmod 700 /home/web/.ssh
```

Place your **secrets** (privately) at `/home/web/.secrets/crav.ini`.  
Then install the INI→ENV sync script and systemd unit:

```bash
sudo tee /usr/local/bin/crav_env_sync.sh >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
INI="/home/web/.secrets/crav.ini"
ENV="/home/web/.secrets/javari.env"
grep -E '^[A-Za-z_][A-Za-z0-9_]*=' "$INI" | sed 's/\r$//' > "$ENV"
chown web:web "$ENV"
chmod 600 "$ENV"
EOF
sudo chmod +x /usr/local/bin/crav_env_sync.sh

sudo cp deploy/systemd/javari.service /etc/systemd/system/javari.service
sudo systemctl daemon-reload
sudo systemctl enable javari.service
```

> The service uses `/home/web/.secrets/javari.env` as `EnvironmentFile` and runs your app from `/var/www/app`.

---

## 4) GitHub Actions secrets (repository → Settings → Secrets and variables → Actions)

Create these **names** with appropriate **values** (never commit them):

- `DEV_HOST`  (Dev server hostname or IP)
- `DEV_USER`  (`web`)
- `DEV_SSH_KEY` (base64 of a private deploy key used by Actions)
- `DEV_PATH`  (`/var/www/app`)

- `PROD_HOST` (Prod server hostname or IP)
- `PROD_USER` (`web`)
- `PROD_SSH_KEY`
- `PROD_PATH` (`/var/www/app`)

**Generate the SSH key** (from your workstation) and install on servers:

```powershell
# Windows PowerShell example
ssh-keygen -t ed25519 -C "gh-actions@craudiovizai" -f "$env:USERPROFILE\.ssh\crav_actions_ed25519"
# Print public key and add it to each server as /home/web/.ssh/authorized_keys
type "$env:USERPROFILE\.ssh\crav_actions_ed25519.pub"
# Add the private key (base64) into GitHub secrets:
[Convert]::ToBase64String([IO.File]::ReadAllBytes("$env:USERPROFILE\.ssh\crav_actions_ed25519")) | clip
```

---

## 5) Deploy pipelines

- **Push to `dev`** → `.github/workflows/deploy-dev.yml` runs → deploys to `craudiovizaidev.com`
- **Merge to `main`** → `.github/workflows/deploy-prod.yml` runs → backup + deploy to `craudiovizai.com`

Both call `deploy/hostinger-deploy.sh` to rsync code, install deps, build, refresh env, and restart `javari.service`.

---

## 6) Replit config

`.replit` (Node example):
```ini
run = "npm install && npm run dev -- --host 0.0.0.0 --port 3000"
```

`replit.nix` (only if prompted):
```nix
{ pkgs }: {
  deps = [ pkgs.nodejs_20 pkgs.git ];
}
```

---

## 7) DNS & Registrar (Squarespace → Hostinger at ~Day 90)

- Today: Squarespace acts only as registrar/DNS for `craudiovizai.com` (records already point to Hostinger)
- Day 90: unlock domain, get EPP/Auth code from Squarespace, start transfer in Hostinger
- Keep the same A/AAAA/CNAME/TXT/MX during transfer
- After transfer: ensure SSL (AutoSSL) and email MX are correct

---

## 8) Notes for Javari

- `javariai.com` will host the **live** Javari dashboard/service on Hostinger, same CI/CD shape.
- Ensure any additional services (queues, DBs, vectors) load creds from `/home/web/.secrets/crav.ini`.
- If Node with PM2 is preferred, replace ExecStart in `javari.service` and add PM2 reload step.

---

## 9) Safety checklist before first deploy

- ✅ Servers created, `web` user present, `/var/www/app` exists
- ✅ `/home/web/.secrets/crav.ini` uploaded privately on both servers
- ✅ systemd service installed and enabled
- ✅ GitHub Actions secrets set (Dev & Prod)
- ✅ DNS for `craudiovizai.com`/`craudiovizaidev.com` points to Hostinger

---

## 10) Daily workflow

1) Replit → code on a `feat/*` branch → push  
2) PR to `dev` → merge → Dev deployment runs  
3) Verify on `craudiovizaidev.com`  
4) PR `dev` → `main` → merge → Prod deployment + backup  
5) Confirm `craudiovizai.com` is healthy

---

**Questions or changes?** Keep this README as the single source of truth and update as you evolve the stack.
